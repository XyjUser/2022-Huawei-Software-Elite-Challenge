def subarraysDivByK2(A, K):
    sum = 0
    rec = {}
    ans = 0
    rec[0] = 1
    for v in A:
        sum += int(v)
        r = (sum % K + K) % K
        if r in rec:
            ans += rec[r]
            rec[r] += 1
        else:
            rec[r] = 1
    return ans


if __name__ == '__main__':
    A = "11012"
    print(subarraysDivByK2(A, 3))

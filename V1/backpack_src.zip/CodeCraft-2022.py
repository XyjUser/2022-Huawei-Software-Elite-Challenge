from baseline import BaseLine

if __name__ == '__main__':
    method = BaseLine()
    method.run()


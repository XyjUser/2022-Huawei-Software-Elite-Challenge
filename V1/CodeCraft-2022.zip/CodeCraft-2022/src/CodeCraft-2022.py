#!/usr/bin/env python
# -*- coding:utf-8 -*-
from baseline import BaseLine
# from baseline_v2 import BaseLine
# from center_opt import CenterOpt
if __name__ == '__main__':
    method = BaseLine()
    method.run()

